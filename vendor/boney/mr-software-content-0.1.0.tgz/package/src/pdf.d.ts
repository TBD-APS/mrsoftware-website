import type { RenderedReport, ExportResult } from './index.js';
export interface RenderPage {
  setContent(html: string, options: { waitUntil: 'load'; timeout: number }): Promise<unknown>;
  pdf(options: { preferCSSPageSize: boolean; printBackground: boolean; tagged: boolean; timeout: number }): Promise<Uint8Array>;
}
export interface ImagePage extends RenderPage { locator(selector: string): { screenshot(options: { type: 'png'; timeout: number }): Promise<Uint8Array> }; }
export type ChartImages = Record<string, { snapshotHash: string; bytes: Uint8Array }>;
export function exportPdf(rendered: RenderedReport, options: { page: RenderPage; timeoutMs?: number }): Promise<ExportResult>;
export function renderChartImages(rendered: RenderedReport, options: { page: ImagePage; timeoutMs?: number }): Promise<ChartImages>;
