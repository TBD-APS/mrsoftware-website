/** The host supplies an already-authorized local Playwright page, its lifecycle and resource policy. */
export async function exportPdf(rendered, { page, timeoutMs = 30000 } = {}) {
  if (!rendered?.hash || !rendered?.html || !page || !Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > 60000) throw new TypeError('PDF export requires a rendered snapshot and a host-owned page');
  // The generated document has no scripts, external fonts, images or data URLs.
  await page.setContent(rendered.html, { waitUntil: 'load', timeout: timeoutMs });
  const bytes = Buffer.from(await page.pdf({ preferCSSPageSize: true, printBackground: true, tagged: true, timeout: timeoutMs }));
  if (bytes.length > 20_000_000 || bytes.subarray(0, 4).toString() !== '%PDF') throw new Error('Invalid or oversized PDF output');
  return { snapshotHash: rendered.hash, bytes, mediaType: 'application/pdf' };
}

export async function renderChartImages(rendered, { page, timeoutMs = 30000 } = {}) {
  if (!rendered?.hash || !page) throw new TypeError('Chart images require a rendered snapshot and host-owned page');
  const images = {};
  for (const chart of rendered.charts) {
    if (!chart.svg) continue;
    await page.setContent(`<style>body{margin:0;background:white}svg{display:block}</style>${chart.svg}`, { waitUntil: 'load', timeout: timeoutMs });
    const bytes = await page.locator('svg').screenshot({ type: 'png', timeout: timeoutMs });
    if (bytes.length > 5_000_000) throw new Error('Chart image exceeds 5 MB');
    images[chart.id] = { snapshotHash: rendered.hash, bytes };
  }
  return images;
}
