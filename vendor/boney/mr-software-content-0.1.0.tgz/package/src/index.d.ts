export type Format = 'integer' | 'number' | 'currency';
export interface Dataset { columns: Record<string, 'string' | 'number' | 'date'>; rows: Record<string, string | number>[]; }
interface Block { id: string; title: string; }
export interface MetricBlock extends Block { type: 'metric'; dataset: string; field: string; format: Format; where?: { field: string; equals: string | number }; }
export interface ChartBlock extends Block { type: 'chart'; dataset: string; kind: 'bar' | 'line'; category: string; measure: string; categoryTitle: string; measureTitle: string; orientation?: 'horizontal' | 'vertical'; }
export interface TableBlock extends Block { type: 'table'; dataset: string; groupBy: string; groupTitle: string; fields: { field: string; title: string; format: Format }[]; }
export interface TextBlock extends Block { type: 'text'; text: string; }
export interface ContentReport {
  version: 1; id: string; title: string; period: string; synthetic: boolean;
  source: { name: string; version: string; at: string; url?: string };
  locale?: string; timezone?: string; currency?: string;
  datasets: Record<string, Dataset>; blocks: (MetricBlock | ChartBlock | TableBlock | TextBlock)[];
}
export type DeepReadonly<T> = T extends object ? { readonly [P in keyof T]: DeepReadonly<T[P]> } : T;
export interface Snapshot { readonly report: DeepReadonly<ContentReport>; readonly json: string; readonly hash: string; }
export interface RenderedChart { readonly id: string; readonly block: DeepReadonly<ChartBlock>; readonly spec: DeepReadonly<Record<string, unknown>>; readonly data: readonly { readonly category: string | number; readonly value: number }[]; readonly svg: string | null; }
export interface RenderedReport extends Snapshot {
  readonly metrics: readonly { readonly id: string; readonly title: string; readonly value: number; readonly display: string }[];
  readonly charts: readonly RenderedChart[]; readonly fragment: string; readonly html: string; readonly css: string;
}
export interface ExportResult { snapshotHash: string; bytes: Uint8Array; mediaType: string; }
export const moduleInfo: Readonly<{ moduleId: 'mr.content'; implementationVersion: '0.1.0'; contractVersion: '1.0.0' }>;
export const reportCss: string;
export function sha256(value: string | Uint8Array): string;
export function createSnapshot(input: ContentReport): Snapshot;
export function renderReport(input: ContentReport, options?: { headingLevel?: 1 | 2; downloads?: { label: string; href: string }[] }): Promise<RenderedReport>;
export function chartData(report: DeepReadonly<ContentReport>, block: DeepReadonly<ChartBlock>): { category: string | number; value: number }[];
export function tableData(report: DeepReadonly<ContentReport>, block: DeepReadonly<TableBlock>): { label: string | number; values: number[] }[];
export function formatNumber(report: DeepReadonly<ContentReport>, value: number, format?: Format): string;
export function toCsv(dataset: DeepReadonly<Dataset>): string;
export function createChartSpec(report: DeepReadonly<ContentReport>, block: DeepReadonly<ChartBlock>, width?: number): Record<string, unknown>;
