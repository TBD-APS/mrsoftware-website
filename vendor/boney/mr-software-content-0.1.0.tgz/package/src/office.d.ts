import type { RenderedReport, ExportResult } from './index.js';
import type { ChartImages } from './pdf.js';
export function exportDocx(rendered: RenderedReport, options: { images: ChartImages }): Promise<ExportResult>;
export function exportXlsx(rendered: RenderedReport): Promise<ExportResult>;
export function exportPptx(rendered: RenderedReport, options?: { images?: ChartImages }): Promise<ExportResult>;
