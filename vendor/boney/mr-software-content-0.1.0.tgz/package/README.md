# Shared content snapshots and exports

`@mr-software/content` 0.1.0 is Boney module `mr.content`, contract 1.0.0.
It renders a host-authorized, versioned JSON report into dashboard HTML/SVG,
PDF, DOCX, XLSX and PPTX. It owns no accounts, provider, database, publication
decision or product data query. The host supplies an explicit source version,
source timestamp, data projection and authorization on every export request.

```js
import { renderReport, toCsv } from '@mr-software/content';
import { exportXlsx, exportDocx, exportPptx } from '@mr-software/content/office';
import { exportPdf, renderChartImages } from '@mr-software/content/pdf';

const rendered = await renderReport(authorizedReport, {
  downloads: [{ label: 'PDF', href: 'report.pdf' }],
});
// A dedicated, host-owned local Playwright page with requests denied.
const images = await renderChartImages(rendered, { page });
const pdf = await exportPdf(rendered, { page });
const word = await exportDocx(rendered, { images });
const excel = await exportXlsx(rendered);
const slides = await exportPptx(rendered, { images });
const csv = toCsv(rendered.report.datasets.records);
```

`src/index.d.ts` defines `ContentReport`. Version 1 supports typed inline datasets
and metric, bar/line chart, grouped table and plain text blocks. Metrics may sum
an explicit equality-filtered field. The report captures and freezes its input
before asynchronous rendering. Every exporter returns `snapshotHash`, bytes and
media type; HTML includes the same hash and the JSON snapshot is available to
the host. Keep receipts with the original file hashes in product-owned storage.
These receipts identify bytes and inputs; they do not prove a business claim,
data quality, customer activation, regulatory status or source authenticity.

One block model supplies the values. HTML has separate readable chart sizes for
phone/desktop; the print document has an A4 layout. `fragment` and `css` can be
embedded in a product's existing shell. `headingLevel: 2` nests under a product
heading. `html` is a standalone report. The host can replace surrounding layout;
cross-page navigation remains in Product UI's link catalogue.

## Export behavior

- PDF uses a host-owned Playwright-compatible page. This package does not launch
  a browser, choose credentials or contact a rendering service. Use a dedicated
  context, deny requests, bound its lifetime and close it in `finally`. No browser
  dependency is required for HTML, SVG or Excel/native bar chart exports.
- Word has editable text/tables and vector SVG charts with same-snapshot PNG
  fallbacks for older readers. The graph is an image, not a native Word chart.
- Excel has typed raw data, report metadata, editable chart-data sheets and native
  bar/line charts pointing to those cells. Dates use date axes. There are no
  external workbook links or macros; arbitrary input text is a string cell.
- PowerPoint has editable text, tables and native bar charts with embedded Excel
  data. Temporal lines use the vector SVG to preserve proportional date spacing;
  they are not replaced with misleading equally spaced category charts.
- CSV quotes cells, preserves numeric cells and neutralizes formula-looking text.
  CSV is not XLSX and does not carry number formats or charts.

SVG/PNG fallbacks must come from `renderChartImages` for the same snapshot. The
host is trusted to render faithfully; a supplied PNG is not independently proven
to depict the source. Empty data is explicit, with zero sums and no invented graph.

## Limits and host responsibilities

Inputs are bounded to 2 MB, 10,000 total rows, 10 datasets, 20 columns/dataset,
20 blocks, 20 categories/chart and 200 groups/table. Numbers must be finite and
bounded; unsupported fields, invalid dates and invalid block types fail. This is
visual/report arithmetic using JavaScript numbers, not an accounting ledger.
Products own unit/currency meaning, exact decimal calculations and required fields.

Only controlled chart templates and inline values reach Vega. Text is escaped;
arbitrary HTML, Vega programs, external data URLs and model-generated executable
code are not supported. The exported document contains no scripts or external
fonts. These controls are not a sandbox for untrusted server jobs: hosts must
still enforce input admission, concurrency/time/storage limits, current tenant
access, cancellation and approved destinations. Data scope is not tenant authority.

Office outputs are ordinary OpenXML files. Different Office/LibreOffice versions
can paginate or style them differently. Native graph/data structures are exercised
by tests; this is not a promise of pixel-identical appearance in every editor.
Large tables may paginate. The first consumer is the public website roadmap;
private task/dashboard snapshots never become public report inputs.

## Producer/consumer release

Run `bash scripts/test.sh content`. It checks the contract, native Office parts,
same-snapshot images, TypeScript declarations, real Chromium PDF/Word generation,
desktop/phone/narrow layout and absence of network calls. Run the full baseline
before pushing. `artifacts` also builds the bundled entrypoints and runs an
isolated empty-cache offline consumer against the exact tarball.

Runtime libraries are bundled with their notices. Consumers pin the original
`mr-software-content-0.1.0.tgz` from a green producer main build and retain the
original manifest/integrity/source revision. Do not substitute a locally rebuilt
archive, relabel a released version or treat a dirty smoke as release evidence.
Products supply their own host page and storage; there is no automatic deployment.

The renderer reuses Workslip's Vega-Lite representation pattern and the official
Vega libraries, without copying its API token, product queries or demo map. Boney
Documents remains the source/evidence contract and text-review PDF capability;
this presentation package does not replace document intake/review or approvals.

References: [Vega](https://vega.github.io/vega/docs/api/view/),
[DOCX](https://docx.js.org/), [ExcelJS](https://github.com/exceljs/exceljs),
[PptxGenJS](https://gitbrent.github.io/PptxGenJS/docs/api-charts.html).
