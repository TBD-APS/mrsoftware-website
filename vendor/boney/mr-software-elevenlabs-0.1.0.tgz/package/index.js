export const maximumBodyBytes = 1024 * 1024;
export const moduleInfo = Object.freeze({ moduleId: 'mr.elevenlabs', implementationVersion: '0.1.0', contractVersion: '1.0.0', capability: 'elevenlabs.webhooks.receive' });
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const maximumAgeSeconds = 30 * 60;
const futureSkewSeconds = 60;

export class ElevenLabsWebhookError extends Error {
  constructor(code, status) {
    super('ElevenLabs webhook rejected.');
    this.name = 'ElevenLabsWebhookError';
    this.code = code;
    this.status = status;
  }
}
const reject = (code, status = 400) => { throw new ElevenLabsWebhookError(code, status); };
const hex = bytes => Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');

// The signature covers the original timestamp text and exact body bytes. Never reserialize JSON first.
export async function verifyWebhook({ body, signature, secret, now = Date.now() }) {
  if (!(body instanceof Uint8Array) || body.byteLength > maximumBodyBytes) reject('body_too_large', 413);
  body = body.slice();
  if (typeof secret !== 'string' || !secret.trim()) reject('not_configured', 503);
  if (typeof signature !== 'string' || signature.length > 4096) reject('signature_invalid', 401);
  const fields = signature.split(',').map(part => part.trim());
  const timestamps = fields.filter(part => part.startsWith('t='));
  const signatures = fields.filter(part => part.startsWith('v0='));
  if (timestamps.length !== 1 || signatures.length < 1 || signatures.length > 8) reject('signature_invalid', 401);
  const timestamp = timestamps[0].slice(2);
  if (!/^[0-9]{1,12}$/.test(timestamp) || signatures.some(part => !/^v0=[a-fA-F0-9]{64}$/.test(part))) reject('signature_invalid', 401);
  const age = Math.floor(now / 1000) - Number(timestamp);
  if (!Number.isFinite(age) || age > maximumAgeSeconds || age < -futureSkewSeconds) reject('signature_invalid', 401);
  const prefix = encoder.encode(timestamp + '.');
  const signed = new Uint8Array(prefix.length + body.length);
  signed.set(prefix); signed.set(body, prefix.length);
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  let valid = false;
  for (const candidate of signatures) {
    const digest = Uint8Array.from(candidate.slice(3).match(/../g), pair => parseInt(pair, 16));
    valid = (await crypto.subtle.verify('HMAC', key, digest, signed)) || valid;
  }
  if (!valid) reject('signature_invalid', 401);
  let envelope, rawBody;
  try { rawBody = decoder.decode(body); envelope = JSON.parse(rawBody); }
  catch { reject('envelope_invalid'); }
  // Retain unknown event types for explicit host processing; they do not grant actions or delivery status.
  if (!envelope || Array.isArray(envelope) || typeof envelope !== 'object'
    || typeof envelope.type !== 'string' || !/^[a-z][a-z0-9_.-]{0,127}$/.test(envelope.type)
    || !Number.isSafeInteger(envelope.event_timestamp) || envelope.event_timestamp < 0 || envelope.event_timestamp > 253402300799
    || !envelope.data || Array.isArray(envelope.data) || typeof envelope.data !== 'object') reject('envelope_invalid');
  return { type: envelope.type, eventTimestamp: envelope.event_timestamp, data: envelope.data, rawBody,
    eventKey: hex(new Uint8Array(await crypto.subtle.digest('SHA-256', body))) };
}

async function readBody(request) {
  const length = request.headers.get('content-length');
  if (length !== null && (!/^[0-9]+$/.test(length) || Number(length) > maximumBodyBytes)) reject('body_too_large', 413);
  const reader = request.body?.getReader();
  if (!reader) reject('envelope_invalid');
  const chunks = [];
  let size = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maximumBodyBytes) { await reader.cancel(); reject('body_too_large', 413); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const body = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { body.set(chunk, offset); offset += chunk.byteLength; }
  return body;
}

const scopeValid = scope => scope && ['tenantId', 'applicationId', 'connectionId'].every(name =>
  typeof scope[name] === 'string' && /^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,199}$/.test(scope[name]));
const response = (status, code) => Response.json({ status: code }, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });

// Options are trusted server-side bindings, never values taken from query parameters or the payload.
// authorize must resolve current module/capability authority. inbox.store must commit atomically before returning.
export async function receiveWebhook(request, { enabled = false, secret, scope, inbox, authorize, now = Date.now() } = {}) {
  if (request.method !== 'POST') return new Response(null, { status: 405, headers: { Allow: 'POST', 'Cache-Control': 'no-store' } });
  if (enabled !== true || !scopeValid(scope) || typeof inbox?.store !== 'function' || typeof authorize !== 'function') return response(503, 'not_configured');
  if (!/^application\/json(?:\s*;|$)/i.test(request.headers.get('content-type') ?? '')
    || ![null, 'identity'].includes(request.headers.get('content-encoding'))) return response(415, 'content_type_invalid');
  try {
    const event = await verifyWebhook({ body: await readBody(request), signature: request.headers.get('elevenlabs-signature'), secret, now });
    const boundScope = Object.freeze({ tenantId: scope.tenantId, applicationId: scope.applicationId, connectionId: scope.connectionId });
    if (await authorize(boundScope, moduleInfo) !== true) return response(503, 'module_unavailable');
    const outcome = await inbox.store(boundScope, event);
    if (!['accepted', 'duplicate'].includes(outcome)) return response(503, 'inbox_unavailable');
    return response(200, outcome);
  } catch (error) {
    if (error instanceof ElevenLabsWebhookError) return response(error.status, error.code);
    // Provider transcripts, secrets and database exception text never become HTTP output or logs.
    return response(503, 'inbox_unavailable');
  }
}

// A single INSERT enforces uniqueness and persistence even for simultaneous deliveries or a lost HTTP response.
export function createD1Inbox(database) {
  return {
    async store(scope, event) {
      if (!scopeValid(scope)) throw new Error('Invalid inbox scope.');
      const result = await database.prepare(`INSERT INTO elevenlabs_inbox
        (tenant_id, application_id, connection_id, event_key, event_type, event_timestamp, payload, received_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?) ON CONFLICT (tenant_id, application_id, connection_id, event_key) DO NOTHING`)
        .bind(scope.tenantId, scope.applicationId, scope.connectionId, event.eventKey, event.type, event.eventTimestamp, event.rawBody, Math.floor(Date.now() / 1000)).run();
      if (result.success !== true || ![0, 1].includes(result.meta?.changes)) throw new Error('Inbox persistence was not confirmed.');
      return result.meta.changes === 1 ? 'accepted' : 'duplicate';
    }
  };
}
