# @mr-software/elevenlabs

Shared Web Crypto receiver for module `mr.elevenlabs` 0.1.0 / contract 1.0.0.
Exports `verifyWebhook`, `receiveWebhook`, `createD1Inbox`, `moduleInfo`,
`maximumBodyBytes` and `ElevenLabsWebhookError`. The separate .NET runtime is
`Boney.ElevenLabs` 0.1.0.

The receiver is disabled by default. Supply a trusted tenant/application/connection
scope, the per-connection HMAC signing secret, current `authorize(scope, module)`
authority and an inbox with an atomic `store(scope, event)` operation returning
`accepted` or `duplicate` only after durable commit. Otherwise it returns 503.
It accepts only POST JSON requests, bounds bodies to 1 MiB and verifies the exact
raw bytes before parsing or storing anything. A valid delivery is at most 30
minutes old and at most 60 seconds in the future. API keys are not signing secrets.

`createD1Inbox(database)` uses the opt-in schema exported as
`@mr-software/elevenlabs/inbox.sql`. Installation does not run migrations.
Receipts are unique per trusted scope and payload SHA-256, so a newly signed
redelivery cannot add a second row. Await the receiver before replying. Store
errors return 503; transcripts and error details are never echoed or logged.
No read API or business processing is supplied. Hosts own private storage,
current rights, retention, erasure and separately idempotent side effects.
Unknown signed event types are retained, never executed. Large audio is outside
the size limit and should not be subscribed without a separate storage design.

The intended company-site callback is
`https://mrsoftware.dk/api/webhooks/elevenlabs`. A package does not deploy that
address or configure an ElevenLabs workspace. See Boney `docs/elevenlabs.md`
for the complete activation and .NET host contracts.
